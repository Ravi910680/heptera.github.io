<?php
$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$dbname45 = "heptera-api-send-table";

$send_api_table_conn = mysqli_connect($servername, $username, $password,$dbname45);



?>
