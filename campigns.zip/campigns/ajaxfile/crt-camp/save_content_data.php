<?php



$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$db="camp_email_db";


$camp_name_conn = mysqli_connect($servername, $username, $password,$db);


function hit_query_php($conn,$sql){


if ($conn->query($sql) === TRUE) {
  return 1;
} else {
  return $conn->error;
}



}




$mail_temp=$_POST['temp_name'];

$mail_sub=$_POST['mail_sub'];

$mail_pre=$_POST['mail_pre'];

$sender_id_send=$_POST['sender_id'];

$smtp_id=$_POST['smtp_id'];

$con_id_dt=$_POST['con_id'];


$del_old_lst="delete from camp_content_tbl where camp_id='".$con_id_dt."'";

$res_del=hit_query_php($camp_name_conn,$del_old_lst);





$isrt_of_con_data="insert into camp_content_tbl values('$mail_temp','$mail_sub','$mail_pre','$sender_id_send','$smtp_id','$con_id_dt')";



$res_del=hit_query_php($camp_name_conn,$isrt_of_con_data);

echo $res_del;







?>