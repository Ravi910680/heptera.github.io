<?php
session_start();

$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$dbname = "storefile";
$dbname2="filemail";
$conn3 = mysqli_connect($servername, $username, $password,$dbname);

$conn2 = mysqli_connect($servername, $username, $password,$dbname2);








$id=$_SESSION['id'];

$sel_aud_query="select * from filedetails where id='".$id."'";


$result = $conn2->query($sel_aud_query);

$arr_of_dt=array();

while($row = $result->fetch_assoc()) {

  
    $loc_arr=array();
$file_name_dec=base64_decode(explode("^", $row['filename'])[1]);

$loc_arr['label']=$file_name_dec;
$loc_arr['value']=$row['filename'];

 
array_push($arr_of_dt, $loc_arr);


  }


$dt_od_lst= json_encode($arr_of_dt);



echo $dt_od_lst;

?>