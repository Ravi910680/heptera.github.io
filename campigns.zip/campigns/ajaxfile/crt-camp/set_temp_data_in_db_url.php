<?php

require("../../confige/save_url_db_confige.php");




function getValidUrlsFrompage($html)
  {
    $links_ret =array();
   
//Create a new DOM document
$dom = new DOMDocument;

//Parse the HTML. The @ is used to suppress any parsing errors
//that will be thrown if the $html string isn't valid XHTML.
@$dom->loadHTML($html);

//Get all links. You could also use any other tag name here,
//like 'img' or 'table', to extract other tags.
$links = $dom->getElementsByTagName('a');

//Iterate over the extracted links and display their URLs
foreach ($links as $link){
    //Extract and show the "href" attribute.
   
$url_dt=$link->getAttribute('href');



if (filter_var($url_dt, FILTER_VALIDATE_URL) !=FALSE) {

    array_push($links_ret,$url_dt );

}


}

    return $links_ret;
  

}


function getInbetweenStrings($start, $end, $str){
    $matches = array();
    $regex = "/$start([a-zA-Z0-9_]*)$end/";
    preg_match_all($regex, $str, $matches);
    return $matches[1];
}


function isrt_url_data_in_db($conn,$url_id,$url){



$isrt_query_db="insert into temp_url_data_crw value('$url_id','$url')";

if ($conn->query($isrt_query_db) === TRUE) {
 


 return 1;

}

return 0;

}


$camp_name=$_POST['camp_id'];




$camp_temp_name=$_POST['temp_id'];

$camp_save_dt_name=$camp_name."#".$camp_temp_name.".php";



$html = file_get_contents("../../../template/crt-template/crtedtemp/".$camp_temp_name.".html");


$links = getValidUrlsFrompage($html);


 $flg_of_num_hr=10;

 $var_of_suc_url=10;

foreach ($links as $key => $value) {
	




$create_red_url="http://ec2-3-12-107-213.us-east-2.compute.amazonaws.com/test/open_url_data_db.php?con_id=<?php echo \$_GET['con_id'];?>&lst_name=<?php echo \$_GET['lst_name'];?>&camp_name=".$camp_name."@".$flg_of_num_hr;

$html=str_replace($value,$create_red_url,$html);


$var_of_suc_url+=isrt_url_data_in_db($url_temp_camp_conn ,$camp_name."@".$flg_of_num_hr,$value);



$flg_of_num_hr+=1;

}






$str_arr = getInbetweenStrings(':', ':', $html);


$str_arr=array_unique($str_arr);

foreach ($str_arr as $key => $value) {
    

$html=str_replace(":".$value.":","<?php echo \$_GET['".$value."'];?>",$html);


}




$myfile = fopen("../../camp_temp/".$camp_save_dt_name, "w") or die("Unable to open file!");
$txt = $html;

$open_res_img_tag="<img src='http://ec2-3-12-107-213.us-east-2.compute.amazonaws.com/test/open_data_of_mail_act.php?lst_name=<?php echo \$_GET['lst_name'];?>&camp_name=".$camp_name."&con_id=<?php echo \$_GET['con_id'];?>'>";

fwrite($myfile, $open_res_img_tag);

fwrite($myfile, $txt);
fclose($myfile);











echo 1;












?>