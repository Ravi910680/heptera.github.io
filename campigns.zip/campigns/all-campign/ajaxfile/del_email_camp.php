<?php


session_start();
require("../../confige/camp_confige.php");


$data=$_POST;

$camp_name_req=$data['camp_name'];

function del_camp_all($conn,$del_field,$val,$tbl){



$del_query="DELETE FROM ".$tbl." WHERE ".$del_field."='".$val."'";

if ($conn->query($del_query) === TRUE) {
  return 1;
} else {
  return 0;
}



}



if(del_camp_all($camp_name_conn,'camp_contact_id',$camp_name_req,'camp_name_tbl')){


if(del_camp_all($camp_name_conn,'camp_id',$camp_name_req,'camp_content_tbl')){

if(del_camp_all($camp_name_conn,'camp_con_id',$camp_name_req,'camp_contact_tbl')){





echo 1;


}




}


}



?>