
const mysql = require("mysql");

  HOST= "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
  USER= "gautam910";
  PASSWORD= "Ravi91068";
  DB= "storefile";






// Create a connection to the database
const connection = mysql.createConnection({
  host: HOST,
  user: USER,
  password: PASSWORD,
  database: DB
});

// open the MySQL connection
connection.connect(error => {
  if (error) throw error;
  console.log("Successfully connected to the database.");
});

module.exports = connection;