<style type="text/css">

.lds-side-nav {
    text-align: center;

  }
.own-dsg-of-dp-side a:hover {
    background: #230323;
    color: white;
}
</style>


<div class="side-nav-container" style='background:#350835;border-top: 0.5px solid white;'>

    <div class="container-of-side-nav-lnk">
    
        <div class="pers-link-side-nav lnk_clk" data-href="main/profile"><i class="fal fa-user-alt"></i>Profile</div>
       

        <div class="dropdown show dp-side-main-con">

       <span class=" dp-trg-btn-side" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fad fa-caret-square-down"></i><span class='pad-left-20px-dp'>SMTP</span></span><i class="fal fa-plus-circle add-crt-dp-btn lnk_clk" data-href="smtp/add_smtp"></i>

  <div class="dropdown-menu own-dsg-of-dp-side" aria-labelledby="dropdownMenuLink" id='all-smtp-server' style='border:0px !important'>
    <div class="lds-side-nav"><div class="cp-spinner cp-round"></div></div>
  </div>
</div>
       
<div class="dropdown show dp-side-main-con">

        <span class=" dp-trg-btn-side" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fad fa-caret-square-down"></i><span class='pad-left-20px-dp'>Sites</span></span><i class="fal fa-plus-circle add-crt-dp-btn lnk_clk" data-href="sites/add_sites"></i>


  <div class="dropdown-menu own-dsg-of-dp-side" aria-labelledby="dropdownMenuLink" id="all-sites-conn" style='border:0px !important'>
    <div class="lds-side-nav"><div class="cp-spinner cp-round"></div></div>
  </div>
</div>

<div class="dropdown show dp-side-main-con">

        <span class=" dp-trg-btn-side" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fad fa-caret-square-down"></i><span class='pad-left-20px-dp'>Sender</span></span><i class="fal fa-plus-circle add-crt-dp-btn lnk_clk" data-href="sender/add_sender"></i>


  <div class="dropdown-menu own-dsg-of-dp-side" aria-labelledby="dropdownMenuLink" id='all-sender-id' style='border:0px !important'>
  <div class="lds-side-nav"><div class="cp-spinner cp-round"></div></div>
  </div>
</div>



        
        <div class="pers-link-side-nav"><i class="fal fa-globe"></i>Connect</div>
        <div class="pers-link-side-nav"><i class="fal fa-power-off"></i>API</div>
        <div class="pers-link-side-nav"><i class="fal fa-usd-circle"></i>Plan</div>

    
    
    </div>


    </div>




<script>





</script>
