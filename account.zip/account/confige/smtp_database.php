<?php
$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$db="smtp_data";

$conn_smtp = mysqli_connect($servername, $username, $password,$db);

?>
