$(document).on('click',".lnk_clk",function(){
$(".main-con-container").css("text-align","center");	
$(".main-con-container").html('<div class="cp-spinner cp-round" style="margin-top:30px;"></div>');
	lnk_path=$(this).attr("data-href");



	window.location.href="https://account.sycista.com/account/"+lnk_path;



})
