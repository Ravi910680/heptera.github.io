<?php
$servername = "database.cvzwmawluvxi.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="signup";

$conn_url = mysqli_connect($servername, $username, $password,$db);

?>
