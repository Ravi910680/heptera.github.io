
<?php 

$email=$_GET['email'];

?>


<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="icon" href="https://res.cloudinary.com/heptera/image/upload/v1601995432/home_page/logo_heptera_1_jjjqnu.png" type="image/png" sizes="32x32">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="http://localhost/coming/css/main.css">
<link rel="stylesheet" type="text/css" href="../design/loader.css">
<style type="text/css">



























body{
font-family: "Roboto";


}

.page-image-con.col-lg-7 {
    height: 100vh;
    background: #4a154b;
}
.head-name-logo {
    height: 20vh;
    padding: 30px;
    color: white;
    }
    .img-con-sign-up-page-main {
    height: 60vh;
    text-align: center;
}

.lgs-txt {
    display: inline-block;
    font-weight: 900;
    font-size: 20px;
    }
    img.img-con-sign-up-page {
    height: 400px;
}


.form-con-sign-up.col-lg-5 {
    padding: 0px 50px;
    height: 100vh;
    overflow: scroll;
    }

    .space-vert-20vh {
        text-align: center;
    height: 20vh;
}

.main-head-line-sg-up-page {
    font-weight: 900;
    }

    .space-vert-10vh {
        text-align: center;
    height: 10vh;
}

.lbl-for-acc-page{
    font-weight: 500;
    font-size: 14px;
    color: #3D3D3D;
    text-align: left;
    margin-bottom: 8px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}


.ip-by-def-dsg{
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;
}

.ip-by-def-dsg:focus{
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



.ip-by-def-dsg-danje{
  background-color: #fff;
    outline: 0;
    border-color: #e20922;
    box-shadow: 0 0 0 3px #e2092245;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



button.btn-theme-dsg {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;

    }

    button.btn-theme-dsg:focus {
    box-shadow: 0 0 0 3px #4a154b4d;
    outline: 0;

}

.norm-desg-sml {
    width: 49%;
    display: inline-block;
    color: #636363;
    font-size: 14px;
    font-weight: 500;
    }

    .row{
        margin:0px;
    }


.dis-nan-in-mob{

display: none;

}

.note-of-main-page {
    font-family: Roboto;
    font-style: normal;
    font-weight: initial;
    line-height: normal;
    font-size: 14px;
    color: #636363;
    text-align: center;
    padding: 40px;

}
span.error-of-sub-form {
    color: red;
}



.form-con-sign-up.col-lg-5::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.form-con-sign-up.col-lg-5 {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}


button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

a{
    border-bottom: 0px;
}

@media (min-width: 768px) and (max-width: 1024px) {
  
  
  
}



@media (min-width: 768px) and (max-width: 1024px) and (orientation: landscape) {
  
 
  
}



@media (min-width: 481px) and (max-width: 767px) {
  
  
  
}


@media (min-width: 320px) and (max-width: 480px) {
  
 
 .page-image-con.col-lg-7{
    display: none;
 }
.dis-nan-in-mob{
    display: block;
}
  
}

















</style>

</head>

<body>

<div class="">
    
        <div class="page-image-con col-lg-7">
    
    
<div class="head-name-logo">

    <div class="c-slacklogo">
<img src="https://res.cloudinary.com/heptera/image/upload/v1599381345/home_page/temp-main-logo_ljkcyj.svg" width="40" style="
    padding-bottom: 10px;
">

    <div class="lgs-txt">
    
    Sycista<span class="spn-ln-lg">|</span><sub>mail</sub>
    
    </div>
</div>
    
</div>
         
            <div class="img-con-sign-up-page-main">

    <img class="img-con-sign-up-page" src="https://res.cloudinary.com/heptera/image/upload/v1601439657/account/happy-bunch_qskbvn.png">

</div>


<div class="space-vert-20vh">


<a href="https://slack.com/intl/en-in/get-started" class="c-button v--secondary v--no-border ">Explore Feature</a>

</div>

        </div>



        <div class="form-con-sign-up col-lg-5">
       
    

<div class="space-vert-20vh">



<div class='dis-nan-in-mob'>


<div class="head-name-logo" style='height:auto;padding:40px 0px;'>

    <div class="c-slacklogo">
<img src="https://res.cloudinary.com/heptera/image/upload/v1599229092/temp-main-logo_rc1l8f.svg" width="40" style="
    padding-bottom: 10px;
">

    <div class="lgs-txt" style='color:black'>
    
    Sycista<span class="spn-ln-lg">|</span><sub>mail</sub>
    
    </div>
</div>
    
</div>



</div>


    </div>
    

<div class="form-of-sign-up">
    
        <div class="main-head-line-sg-up-page">
        
            <h1>Verify Account</h1>
        
        </div><div class="space-vert-10vh"></div>

<div class="main-form-con">


  <div class="form-group">
    <label class="lbl-for-acc-page" for="exampleInputEmail1" style="
">Email address</label>
    <input type="email"  class="ip-by-def-dsg form-control" id="email-fld" aria-describedby="emailHelp" value='<?php echo $email;?>' placeholder="Enter email" disabled>
    
  </div>
  




  <button class="btn-theme-dsg" id='btn-sub-sub'>Verify Account</button>

<div class='row'>

<div class='norm-desg-sml'>

Back To Login

</div>

<div class='norm-desg-sml' style='text-align:right'>

Create Account

</div>

</div>


<div class='note-of-main-page'>

Send link On your verified email address than update new password and keep it safe

</div>




    

</div>
    
    
    
    </div>
    
    
        
        </div>
    
    </div>


</body>
</html>






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script type="text/javascript">









$(document).on('click','#btn-sub-sub',function(){




req_sign_up_fill();



});

function req_sign_up_fill(){


$("#btn-sub-sub").prop('disabled', true);

$("#btn-sub-sub").html('<div class="cp-spinner cp-round"></div>');


email_req=$("#email-fld").val();




$.ajax({
                url : "../login/ajaxfile/login.php",
                type: "POST",
                data : {email:email_req,password:''}
        }).done(function(response){ 


console.log(response);

if(response==2){




$("#btn-sub-sub").html('Resend link');


}else if(response==3){



$("#email-fld").addClass('ip-by-def-dsg-danje');

$("#email-fld").after('<span class="error-of-sub-form">Email Does not exists</span>');

$("#btn-sub-sub").html('Forget password');


}


$("#btn-sub-sub").prop('disabled', false);


        });
  



}


</script>



















