<?php
session_start();

require("../../confige/user_database.php");


$req_data=$_POST;

$email=$req_data['email'];
$pass=$req_data['password'];


$sel_query_usr="select * from userinfo where email='$email'";

$result = $conn_usr->query($sel_query_usr);


if ($result->num_rows > 0) {
  // output data of each row
  $row = $result->fetch_assoc();
    if($row['pass']==$pass){

    	if($row['varflag']==1){


    		$_SESSION['id']=$row['id'];

echo 1;



}else{

echo 4;

}

    }else{

echo 2;

    }

    
  
} else {
  echo 3;
}


?>



