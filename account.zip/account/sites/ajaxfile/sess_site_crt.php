<?php
session_start();


$_SESSION['site_id']=$_GET['site_id'];

$_SESSION['site_name']=$_GET['site_name'];

echo $_SESSION['site_id'];
?>