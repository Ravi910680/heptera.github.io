<?php

require("../../../../confige/url_database.php");
error_reporting(E_ALL ^ E_WARNING); 

$req_data=$_POST;

$url_of_send=$req_data['url_code'];

$url_of_site=base64_decode($url_of_send);

$page=file_get_contents($url_of_site);



$doc = new DOMDocument();
$doc->loadHTML($page);
$divs = $doc->getElementsByTagName('script');

$flg_res=0;

foreach($divs as $div) {
   
   
    if ($div->getAttribute('id') === $url_of_send) {
     
     

     $up_query_tbl="UPDATE url_connect SET status='1' WHERE url='$url_of_site'";



if ($conn_url->query($up_query_tbl) === TRUE) {


$flg_res=1;


} 
 
    }
}

echo $flg_res;

?>