<?php




function httpGet($url)
{
    $ch = curl_init(); 

    $url = str_replace(" ", '%20', $url); 
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
}




function httpGetBody($url,$body)
{
    $ch = curl_init(); 

    $url = str_replace(" ", '%20', $url); 

    curl_setopt($ch,CURLOPT_URL,$url);
 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt($ch, CURLOPT_POST,           1 );
curl_setopt($ch, CURLOPT_POSTFIELDS,     $body ); 
curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/plain')); 
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
}




$req_data=$_GET;



$str_of_repeat="";

$jsn_data=json_decode($req_data['json_data']);



foreach ($jsn_data as $key => $value) {
	




$str_of_repeat.= httpGet("http://localhost/html/dash/main/account/sites/site_data/ajaxfile/get-url-str.php?url=".$value->url);







}

$url_main_temp="http://localhost/html/dash/main/template/edit/temp-blog/main-blog-temp/test-blog.php";


$get_full_temp= httpGetBody($url_main_temp,$str_of_repeat);




$myfile = fopen("../../../../template/edit/temp-blog/temp-crt-con/19.html", "w") or die("Unable to open file!");

fwrite($myfile, $get_full_temp);
fclose($myfile);




?>