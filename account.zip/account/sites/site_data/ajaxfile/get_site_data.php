<?php
session_start();
require("../../../confige/url_database.php");
require("../../../confige/url_crawl_data.php");


$url_id=$_SESSION['site_id'];


$res_arr=array();



$sel_data_frm="select * from url_connect where url_id='$url_id'";



$result = $conn_url->query($sel_data_frm);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

$res_arr['site_data']=$row;



$sel_crw_data="select * from `$url_id`";


$result = $conn_crw->query($sel_crw_data);

if ($result->num_rows > 0) {
  // output data of each row
	$i=0;

	$res_arr['site_data']['count']=$result->num_rows;
  while($row = $result->fetch_assoc()) {

  	

$res_arr['site_data']['data'][$i]=$row;

$i++;

}

}else{

$res_arr['site_data']['count']=0;


}


}


    
  
} else {
  
}

print_r(json_encode($res_arr));




?>