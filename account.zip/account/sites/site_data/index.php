
<?php
session_start();
$mail=$_SESSION['email'];

?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link rel="icon" href="https://res.cloudinary.com/heptera/image/upload/v1601995432/home_page/logo_heptera_1_jjjqnu.png" type="image/png" sizes="32x32">
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="../../design/loader.css">

<style>

.tablediv{
    padding:10%;
}
tr{

border:1px solid #dedddc;
}


.con-of-tbl{
background:white;
border-radius:4px;
}

.col-header th{
padding-top:1rem !important;
padding-bottom:1rem !important;
}
.col-header{


color: white;
    font-size: 20px !important;
    background: darkcyan;
    font-weight: 700 !important;


}
.first-col{

display: block;
    
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


























.head-dash{
  font-family: 'Karla', sans-serif;
  font-size: 23px;
  color: #000000e0;
  width:50%;
}
body{
	
}

.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

.row{
	width:100%;
	margin-left:0px;
	margin-right: 0px;
}
.head-con-rw{
	padding-top: 20px;
	padding-bottom: 20px;
}
.btn-con-top{
	width: 50%;
}

.bottom-btn:hover{
	cursor: pointer;
}







body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{
border-radius:4px;
border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#085861;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}








.con-of-dash-data{
	width:25%;
	margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
	border-radius: 5px;
	background:white;
	margin: 20px;

}

.icon-data-con{

	padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

	display: table-cell;
	vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}

.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}


.head-of-over{
  font-family: 'Karla', sans-serif;
  font-size: 20px;
  color: #000000e0;
  padding-top: 20px;
}



.table{
margin-bottom:0px;
}











.data-tbl-db{
 
  background: white;
  border-radius: 5px;
  
}

.data-belo-line{

    width: 500px;
    overflow: scroll;
    font-weight: 600;
    color: #0000006b;
}

.tbl-main-head{
  color: #000000cc;
    font-weight: bolder;
width: 200px;
    overflow-x: scroll;
}
.tbl-main-head::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE and Edge */
.tbl-main-head {
  -ms-overflow-style: none;
}

.tbl-link-clr{
  color: blue;
transition:.2s;



}


.tbl-link-clr:hover{
color:black;

}











.not-fd-data{
  text-align: center;
background:white;
border-radius:4px;

padding:20px;





}








.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

















@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);


.nav-link:hover{
    cursor:pointer;
}

ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;

}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}


td{
vertical-align: middle;

}

html{
background;#f0f8ffcf;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.con-of-tbl{
background:white;
border-radius:4px;
}
















button.btn_hover_clr {
    margin-top: 10px;

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



.table td, .table th {
    font-size: 16px;
    white-space: nowrap;

  }












.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}













.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }







i:hover{

  cursor: pointer;

}






.card{
  height: min-content;
  width: 30rem;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{

    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;
  }

.container-2GnNH span{

font-size: 13px;

}

.navbar{
  position: relative !important;
  border-bottom: 0px !important;
}

div#main-content {
    height: 92vh;
}
.add-new-site-main-con {
    width: 500px;
    margin: auto;
    text-align: center;
    margin-top: 40px;
    }





.ip-by-def-dsg{
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;
}

.ip-by-def-dsg:focus{
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



.ip-by-def-dsg-danje{
  background-color: #fff;
    outline: 0;
    border-color: #e20922;
    box-shadow: 0 0 0 3px #e2092245;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



button.btn-theme-dsg {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;

    }

    button.btn-theme-dsg:focus {
    box-shadow: 0 0 0 3px #4a154b4d;
    outline: 0;

}


.disp-inline-blc {
    display: inline-block;
    }


.side-nav-container {
    height: 92vh;
    width: 20%;
    display: inline-block;
    overflow: scroll;
    background: #4a154b;
    
  }
  .main-con-container {
    width: 79%;
    display: inline-block;
    height: 92vh;
    overflow: scroll;
    
  }

  div#main-content {
    height: 92vh;
    width: 100%;

    
  }

.container-of-side-nav-lnk {
    padding-top: 40px;
  }

  .pers-link-side-nav {
    padding: 10px 20px;
    color: rgb(207,195,207);
    cursor: pointer;
    transition: .2s;
    font-size: 15px;
  }

.pers-link-side-nav:hover{
  color: white;
}

.fal{
  padding-right: 20px;
}

.note-of-main-page {
    font-family: Roboto;
    font-style: normal;
    font-weight: initial;
    line-height: normal;
    font-size: 14px;
    color: #636363;
    text-align: center;
    padding: 40px;
  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.own-dsg-of-dp-side {
    border-radius: 10px !important;
    position: relative !important;
    transform: unset !important;
    width: 100%;
    overflow: scroll;
  }

  .own-dsg-of-dp-side {
    border-radius: 10px !important;
    position: relative !important;
    transform: unset !important;
    width: 100%;
    background: transparent;

  }

  .own-dsg-of-dp-side a{

  }

  .own-dsg-of-dp-side a {
    padding: 5px 10px !important;
    color: rgb(207,195,207);
    font-size: 13px !important;
  }

  .own-dsg-of-dp-side a:focus{
background: #350c35;
    color: rgb(207,195,207);
  }

.dp-side-main-con {
    width: 100%;
    padding: 10px 20px;
    color: rgb(207,195,207);
    cursor: pointer;
    font-size: 15px;

  }

  .dp-side-main-con:hover{
    color: white;

  }
.own-dsg-of-dp-side a:hover {
    background: #350c35;
    color: white;
  }

  .pad-left-20px-dp{
    padding-left: 20px;
  }

  .add-crt-dp-btn{
    float: right;
    font-size: 20px;
    padding: 0px 10px;
    color: white;
  }

  .fa-hashtag {
    padding-right: 7px;
    margin-right: 0px !important;
}










button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}





i.ico-of-sede-sub-dp {
    margin-right: 0px !important;
    padding-right: 15px;
  }

.head-of-site-main-data {
    padding: 40px 0px;
    width: 800px;
    margin: auto;

  }

button.btn.btn-secondary.had-btn-dsg {
    height: 40px;
    background: white;
    border-radius: 5px;
    border: none;
    font-size: 13px;

  }
  .main-con-of-db{
    width: 800px;
    margin: auto;
  }

#lnk_site_data td{
  
  font-size: 13px;
}





@import url('https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900');
body {
    font-family: 'Roboto', sans-serif;
  }

.card {
    width: 500px;
    margin: 50px auto;
    clear: both;
    display: block;
    padding: 0px 0px;
    background-color: #009BFF;
    border-radius: 4px;
}
.card::after {
    clear: both;
    display: block;
    content: "";
}
.card .checkbox-container {
    float: left;
    width: 50%;
    box-sizing: border-box;
    text-align:center;
  padding: 40px 0px;
}
.card .circular-container {
  background-color:#0067FF;
}

.input-title {
    clear: both;
    padding: 22px 0px 0px 0px;
    font-size: 16px;
    color: rgba(255,255,255,.6);
    font-weight: 300;
}




/* Styling Checkbox Starts */
.checkbox-label {
    display: block;
    position: relative;
    margin: auto;
    cursor: pointer;
    font-size: 22px;
    line-height: 24px;
    height: 24px;
    width: 24px;
    clear: both;
}

.checkbox-label input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

.checkbox-label .checkbox-custom {
    position: absolute;
    top: 0px;
    left: 0px;
    height: 24px;
    width: 24px;
    background-color: transparent;
    border-radius: 5px;
    transition: all 0.3s ease-out;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    border: 2px solid #FFFFFF;
}


.checkbox-label input:checked ~ .checkbox-custom {
    background-color: #FFFFFF;
    border-radius: 5px;
    -webkit-transform: rotate(0deg) scale(1);
    -ms-transform: rotate(0deg) scale(1);
    transform: rotate(0deg) scale(1);
    opacity:1;
    border: 2px solid #FFFFFF;
}


.checkbox-label .checkbox-custom::after {
    position: absolute;
    content: "";
    left: 12px;
    top: 12px;
    height: 0px;
    width: 0px;
    border-radius: 5px;
    border: solid #009BFF;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(0deg) scale(0);
    -ms-transform: rotate(0deg) scale(0);
    transform: rotate(0deg) scale(0);
    opacity:1;
    transition: all 0.3s ease-out;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
}


.checkbox-label input:checked ~ .checkbox-custom::after {
  -webkit-transform: rotate(45deg) scale(1);
  -ms-transform: rotate(45deg) scale(1);
  transform: rotate(45deg) scale(1);
  opacity:1;
  left: 8px;
  top: 3px;
  width: 6px;
  height: 12px;
  border: solid #009BFF;
  border-width: 0 2px 2px 0;
  background-color: transparent;
  border-radius: 0;
}



/* For Ripple Effect */
.checkbox-label .checkbox-custom::before {
    position: absolute;
    content: "";
    left: 10px;
    top: 10px;
    width: 0px;
    height: 0px;
    border-radius: 5px;
    border: 2px solid #FFFFFF;
    -webkit-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0);  
}

.checkbox-label input:checked ~ .checkbox-custom::before {
    left: -3px;
    top: -3px;
    width: 24px;
    height: 24px;
    border-radius: 5px;
    -webkit-transform: scale(3);
    -ms-transform: scale(3);
    transform: scale(3);
    opacity:0;
    z-index: 999;
    transition: all 0.3s ease-out;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
}




/* Style for Circular Checkbox */
.checkbox-label .checkbox-custom.circular {
    border-radius: 50%;
    border: 2px solid blue;
  }

.checkbox-label input:checked ~ .checkbox-custom.circular {
    background-color: #FFFFFF;
    border-radius: 50%;
    border: 2px solid #FFFFFF;
}
.checkbox-label input:checked ~ .checkbox-custom.circular::after {
    border: solid #0067FF;
    border-width: 0 2px 2px 0;
}
.checkbox-label .checkbox-custom.circular::after {
    border-radius: 50%;
}

.checkbox-label .checkbox-custom.circular::before {
    border-radius: 50%;
    border: 2px solid #FFFFFF;
}

.checkbox-label input:checked ~ .checkbox-custom.circular::before {
    border-radius: 50%;
}



















.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
  position: relative;
  display: flex;
  width: 100%;
}
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}





















i.fal.fa-sliders-h {
    padding: 10px;
    font-size: 20px;
    border-radius: 4px;
    color: black;
    transition: .2s;
    }

    i.fal.fa-sliders-h:hover {
    color: blue;
    background: #0000ff0a;

  }

  .dp-show-btn{
    display: none;
  }




    
.myDIV:hover  .hide {
  cursor: pointer;
  display: block;
  position: absolute;;
}

td{
  cursor: pointer;
}

.hide {
    display: none;
    max-width: 200px;
    height: auto;
    padding: 20px;
    background: white;
    border-radius: 5px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

  }

  .badge {
    margin: 0px 4px;
    text-transform: uppercase;
}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>

<body class="" style="">
  
 <?php require("../../../../confige/header/header.html");?>


<div id="main-content">


    <?php require("../../confige/side-nav.php");?>


    <div class="main-con-container" id='add-site-main-con'>


        
<div class="head-of-site-main-data">
        <h1 style="
    color: black;
    font-family: 'Josefin Sans', sans-serif;
">https://heptera.com</h1>
    
    </div>

    

<div class="main-con-of-db">

<div class="tbl-of-site-dt-head">

    <nav class="navbar navbar-horizontal navbar-expand-lg navbar-dark bg-default" style="
    background: white !important;
    padding-left: 0px;
    padding-right: 0px;
">
    <div class="container" style="
    padding: 0px;
">
       



<div class="dropdown" style="
    width: 50%;
"    >

 
<i class="fal fa-sliders-h" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>

  <div class="dropdown-menu" id="opt-of-srch-fld" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute;will-change: transform;width: 100%;left: 0px;transform: translate3d(0px, 40px, 0px);">
    <a class="dropdown-item clc-for-act mlt-lvl-dp" type-filt="type" type-val="email" href="javascript:void(0);"  ><i class="fal fa-envelope" aria-hidden="true"></i>Email



<div class="dp-show-btn">

vfvfvfvfvf

</div>




    </a>
    <a class="dropdown-item clc-for-act" type-filt="type" type-val="social" href="javascript:void(0);"><i class="fal fa-hashtag" aria-hidden="true"></i>Social Post</a>
    <a class="dropdown-item clc-for-act" type-filt="type" type-val="survey" href="javascript:void(0);"><i class="fal fa-poll-h" aria-hidden="true"></i>Survey</a>
  </div>
</div>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-default" aria-controls="navbar-default" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-default">
            <div class="navbar-collapse-header">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="javascript:void(0)">
                            <img src="../../assets/img/brand/blue.png">
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar-default" aria-controls="navbar-default" aria-expanded="false" aria-label="Toggle navigation">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            
            <ul class="navbar-nav ml-lg-auto">
                <li class="nav-item">
                    <button type="button" class="btn-theme-dsg" id='send-for-url-camp' data-modal-trigger='modal-send-api-data' disabled>Go To Campign</button>
                </li>
                
                
            </ul>
            
        </div>
    </div>
</nav>

    
    

</div>


<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col" style='text-align:center;'>For Campign</th>
      <th scope="col">url</th>
      <th scope="col">KeyWords</th>
      <th scope="col" style='text-align:center;'>Crawl Date</th>
    
    </tr>
  </thead>
  <tbody id='lnk_site_data'>
   
    
  </tbody>
</table>


</div>




    </div>



</div>



<div class="modal-2" data-modal="modal-send-api-data" id="modal-send-api-data">
  <article class="content-wrapper">
    <button class="close" data-modal="modal-send-api-data"></button>
    <header class="modal-2-header">
      <h2>Create Post Update campign</h2>
    </header>
    

<div class='template-con-send'></div>

    <div class='content'>
  
<input  class="ip-by-def-dsg form-control" id="crt-camp-name-blog" aria-describedby="emailHelp" placeholder="Enter campign name">


   </div>

<div class="cont-of-res-api-tok-1">

     <button type="button" class="btn-theme-dsg" id='sub_btn_for_camp' data-modal-trigger='modal-send-api-data' >Create Campign</button>

  </div>
   
 
  </article>
</div>




  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script type="text/javascript" src='../../js-file/init_side_nav_data_0.js'></script>
  
  
</body>



</html>

<script type="text/javascript">


$(document).ready(function(){

get_site_data_crt_ses();

})


function get_site_data_crt_ses(){



$.ajax({
                url : "./ajaxfile/get_site_data.php",
                type: "GET"
        }).done(function(response){ 

json_data=JSON.parse(response);



$("#lnk_site_data").html(str_of_app_link_data(json_data['site_data']['data']));





        });
  

}


function str_of_app_link_data(data){

str_of_ret='';

for (var i = 0; i < data.length; i++) {
  

console.log(data[i]);


str_key=get_keyword_str(data[i]['keyword']);


str_of_ret+='<tr><td><label class="checkbox-label" data-url="'+data[i]['url']+'"  data-id="'+data[i]['id']+'"> <input type="checkbox" id="'+data[i]['url']+'"> <span class="checkbox-custom circular"></span> </label></td><td>'+data[i]['url']+'</td><td class="myDIV">'+str_key+'<div class="hide">'+str_key+'</div></td><td>'+data[i]['date']+'</td></tr>';



};

return str_of_ret;


}


function get_keyword_str(key_str){

arr_key=key_str.split(",");

str_ret='';
for (var i = 0; i < arr_key.length; i++) {
  str_ret+='<span class="badge badge-pill badge-warning">'+arr_key[i]+'</span>';
};


return str_ret;

}

$(document).on("click",'.mlt-lvl-dp',function(){



$(this).children(".dp-show-btn").css('display','block');


})


$(document).on('click','.checkbox-label',function(){

$("#send-for-url-camp").prop('disabled', true);

$(".checkbox-label").map(function(){


 

if($(this).children('input')[0].checked==true){

 

  $("#send-for-url-camp").prop('disabled', false);



}

});
  



})


$(document).on('click','#send-for-url-camp',function(){



$(".checkbox-label").map(function(){


 

if($(this).children('input')[0].checked==true){

 
console.log($(this).attr('data-url'));



}

});


modalEvent(this);



})






function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
   

    
    

    modal.classList.toggle('open');
  
}





$(document).on('click','#sub_btn_for_camp',function(){


  name_camp_blg="blog-"+$("#crt-camp-name-blog").val()+"-template";


$.ajax({
  type: "GET",
  url: "./ajaxfile/crt-template-blog.php",
  data: {json_data:'[{"id":"11","url":"https://www.shoutmeloud.com/siteground-vs-bluehost.html"},{"id":"15","url":"https://www.shoutmeloud.com/rank-math-vs-yoast.html"},{"id":"13","url":"https://www.shoutmeloud.com/a2-hosting-reviews.html"}]'}
}).done(function(response1) {


crt_template_of_blg_post("19",name_camp_blg);
  
  
});




})


$(document).on('click','.close',function(){

$("#"+$(this).attr('data-modal')).removeClass('open');

})



function crt_template_of_blg_post(passed_name,crt_name){



decode_name_of_temp=passed_name;



$.ajax({
  type: "POST",
  url: "../../../template/crt-template/ajaxfile/vertempname.php",
  data: {temp_name_get:crt_name,type_temp:decode_name_of_temp,temp_crt_flg:1,path:"../../../template/edit/temp-blog/temp-crt-con/"}
}).done(function(response1) {

  
  
});

}


</script>

