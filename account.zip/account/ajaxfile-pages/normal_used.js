

function auth_complete_loged(){




$.ajax({
                url : "https://account.sycista.com/account/ajaxfile-pages/phpfile/php_check_user_login.php",
                type: "GET"
        }).done(function(response){ 

init_after_loged_stat(response);




});


}
