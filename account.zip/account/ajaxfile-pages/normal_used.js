

function auth_complete_loged(){




$.ajax({
                url : "http://localhost/html/dash/main/account/ajaxfile-pages/phpfile/php_check_user_login.php",
                type: "GET"
        }).done(function(response){ 

init_after_loged_stat(response);




});


}