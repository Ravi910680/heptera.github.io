<?php
session_start();
require("../confige/smtp_database.php");


$arr_resp=array();

$id=$_SESSION['id'];

$sel_all_smtp="select * from smtp_server_data where id='$id'";
$result = $conn_smtp->query($sel_all_smtp);

if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {

array_push($arr_resp, $row);

    
  }

echo json_encode($arr_resp);

} else {
  echo 0;
}





?>