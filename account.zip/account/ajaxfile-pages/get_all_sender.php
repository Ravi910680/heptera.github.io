<?php
session_start();
require("../confige/sender_database.php");


$arr_resp=array();

$id=$_SESSION['id'];

$sel_all_sender="select * from sender_data where id='$id'";
$result = $conn_sender->query($sel_all_sender);

if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {

array_push($arr_resp, $row);

    
  }

echo json_encode($arr_resp);

} else {
  echo 0;
}





?>