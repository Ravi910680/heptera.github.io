<?php
session_start();

$mail=$_SESSION['email'];

?>



<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
 <link href="./../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<link href='https://fonts.googleapis.com/css?family=Karla:700' rel='stylesheet' type='text/css'>
<!-- Latest compiled JavaScript -->

<script src="https://kit.fontawesome.com/a66ec178f8.js" crossorigin="anonymous"></script>
<link href="../fa-fold/css/all.css" rel="stylesheet"> 
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
<style>

@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);
@import url(https://fonts.googleapis.com/css?family=Arvo);
.tablediv{
    padding:10%;
}
body{
  background: white !important;
  font-family 'IBM Plex Sans', sans-serif !important;
}

.temp_con {
    padding: 20px;
    width: fit-content;
    border-radius: 5px;
    border: 1px solid #f2f2f2;
    margin-bottom: 20px;
    background: white;
    transition: .5s;
    box-shadow: 0 0 2rem rgba(0,0,0,.1);

    }
.temp_con:hover {
    cursor: pointer;
    box-shadow: 0 0 2rem rgba(0,0,0,.2);
    transform: scale(1.05);

  }
.row{
margin-left:0px !important;
margin-right:0px !important;
}
.temp_name_sty{

width:180px !important;
    color: #341161;
    font-family: 'Nunito Sans','Avenir Next','Segoe UI','Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif !important;
    white-space: nowrap !important;
    overflow: hidden !important;
    text-overflow: ellipsis !important;
    font-size: 17px !important;
    font-weight: 540 !important;
    letter-spacing: 0.8px !important;
}
.btn-my:hover{
    outline:2px solid !important;
    cursor:pointer !important;

}
.card:hover{
    cursor:default !important;
}
.btn-my{
    height:50px;text-align:center;background:#f2f2f2;border:none !important;
    
}
.btn-my:active{
    border:2px solid !important;
}
.btn-my:focus{
    border:2px solid !important;
}




.bottom-btn{
  text-align: center !important;
    height: 40px !important;
    background: #104b7b !important;
    color: white !important;
    font-weight: 800 !important;
    font-size: 15px !important;
    border-radius: 4px !important;
    border: none !important;
    float: right !important;
    padding-left: 20px !important;
    padding-right: 20px !important;
}




.nav-link:hover{
    cursor:pointer !important;
}
.sticky {

  position: fixed !important;
  top: 0 !important;
  width: 100% !important;
  z-index: 10 !important;
}
.lablecon{
    padding:40px !important;
    max-width:70% !important;
}
.submiturl:hover{
    border:2px solid !important;
} 
ul{
    list-style:none !important;
}
.stepst3{
    font-size:30px !important;
    display: inline-block !important;
    width: auto !important;
    height: auto !important;
    margin: 6px !important;
    
}


.modal-input:focus{

outline: none !important;
    border: 1px solid #007c89 !important;
    box-shadow: inset 0 0 0 2px #007c89 !important;

}



.addsiteheadbtn:hover{
    color:black !important;
    cursor:pointer !important;
    background:#d9d7cd !important;

}

#loader {
  position: absolute !important;
  left: 50% !important; 
  top: 50% !important;
  z-index: 1 !important;
  width: 150px !important;
  height: 150px !important;
  margin: -75px 0 0 -75px !important;
  border: 5px solid #f3f3f3 !important;
  border-radius: 50% !important;
  border-top: 5px solid black !important;
  width: 40px !important;
  height: 40px !important;
  -webkit-animation: spin .5s linear infinite !important;
  animation: spin .5s linear infinite !important;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px !important;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
	cursor: pointer;
}

.bottom-btn:focus{
  outline: none !important;
}
.bottom-btn:active{
  outline: none !important;
}




.res_of_hepta {
    padding: 10px;
    background: #0700ff1f;
    color: black;
    font-weight: 600;
    border-radius: 5px;
    border: 4px solid #0008ff4f;
display:none;


}



.not-fd-data{
  width: 100%;
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}



.note-editable {
    line-height: 2;
}

button#dropdownMenuButton {
    background: none;
    border: none;
    font-size: 20px;
    color: #341161;
    margin: 0px;
    width: 20px;
    }

.fal{
  
}
.dropdown-item{
padding:4px 8px 4px 16px !important;
font-size: 14px;
color: black;
}
.dp-fr-opt-act .dropdown-item:hover{
  background: #0d66d6;
  color: white;

}

#dropdownMenuButton:hover{
cursor: pointer;

}

i.fal {
    width: 20px !important;
  }





.pdfobject-container {
  height: 30rem;
  border: 1rem solid rgba(0, 0, 0, 0.1);
}




.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
  position: relative;
  display: flex;
}
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}
.content p{

color: #000000ab;
    font-weight: 500;

}

a.crt-api-btn-fin {
    background-color: #3368fa;
    color: white;
    padding: 10px;
    font-size: 15px;
    border-radius: 3px;

  }

  .cont-of-res-api-tok {
    border: 1px solid #a59f9f !important;
    border-radius: 5px;
    color: #777373;
    width: 70%;
  }

  input.hold-token-ip {
    height: 40px;
    border: none;
    border-radius: 5px;
    width: 90%;
    padding: 10px;
  }
  input.hold-token-ip:focus{

  }

  .copy-clip-tok {
    font-size: 20px;
    display: inline-block;
    width: 10%;
  }
  .cont-of-res-api-tok{
    margin: auto;
  }
.template-con-send {
    color: green;
    font-weight: 700;
    padding-bottom: 10px;
    }



.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }


button.btn-theme-dsg {
  font-family 'IBM Plex Sans', sans-serif !important: 
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;


  }

button.btn_hover_clr {
  font-family 'IBM Plex Sans', sans-serif !important: 
    margin-top: 10px;
    background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    font-size: 13px;
    font-weight: 500;
    float: right;
    color: #471f48f0;

  }

  button.btn_hover_clr:hover {
    background: #b284b336;
    cursor: pointer;

  }

  .modal{
    z-index: 10000000000;
  }


  .ip-by-def-dsg {
    font-family 'IBM Plex Sans', sans-serif !important;
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}


.full-mdl-con-lrg {
    width: 100%;
    height: 60vh;
    background: white;
border-radius: 10px;
  }

  .tw-rw-mdl-con {
    width: 49.7%;
    height: 60vh;
    display: inline-block;
    overflow: scroll;
    padding: 40px;
  }
  p.mdl-lrg-notc-txt {
    font-size: 13px;
    color: #565454;
    font-weight: 500;
    }

button#dropdownMenuButton:focus{
  outline: none;
  border: none;
}


.modal-body {
    position: relative;
    flex: 1 1 auto;
    padding: 0rem;
    margin: 1.5rem;
    overflow: scroll;

  }
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->
 
</head>
<div id="c"></div>
<body class="" style="">
  <?php require("./confige/header/header.html");?>

<div class="main-content">




<div class="full-mdl-con-lrg" style="
    border-radius: 0px;
    background: #eef0f1;
    margin: auto;
">
    
        <div class="tw-rw-mdl-con" style="padding:0px;">

    <img src="https://res.cloudinary.com/heptera/image/upload/v1603554673/template/Email_campaign-bro_mjjgnp_ehwhqt.svg" style="width: 100%;margin-top: auto;height: 100%;">
    
</div>
        <div class="tw-rw-mdl-con">
 
    
    <div style="font-size:30px;font-family: 'Karla', sans-serif;color: #350835;text-align:center;width:100%;letter-spacing: 0px;">
Template
</div>
    
    <div style="text-align:center">
<div class="row">
<div class="" style="padding:20px;width:50%;float:right;">
<a class="red_norm_url" red-url-dt="../studio"><button class="btn_hover_clr" style="
    background: white;
"><i class="fal fa-camera-retro" aria-hidden="true" style="
    padding-right: 10px;
"></i>Go To Studio</button></a>
</div>

<div class="" style="padding:20px;width:50%;float:left;">
<a class="red_norm_url" red-url-dt="./crt-template"><button class="btn_hover_clr" style="float:left;background: #350835;color: white;"><i class="far fa-edit" aria-hidden="true" style="
    padding-right: 10px;
"></i>Creat Template</button></a></div>
</div>
</div>


<p class="mdl-lrg-notc-txt" style="
    width: 40;
    width: 50%;
    margin: auto;
">Create Your New email template Without more stuff and easily deploy in Sycista System.</p>

<button class="btn-theme-dsg" id="click_to_con" type="submit" style="
    float: none;
    width: 60%;
    margin: auto;
    margin-top: 40px;
"><span>Explore More About Template</span><i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button>

</div>
        
    
    
    </div>








  
<div style='width:100%;padding-top:3%;padding-bottom:5%;padding-right:15%;padding-left:15%;' >




<div class="res_of_hepta" id='res_of_proc'>
    
</div>





<div id='temp_res_of_con' style=''>
<div class="row" id='temp_to_res' style="">










</div>
</div>




</div>


</div>


<div id='res'>
</div>








<div class="modal-2" data-modal="rename_temp_name_modal" id='rnm-mdl-con'>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change Template Name</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i class="fal fa-times-circle"></i></span>
        </button>
      </div>
      <div class="modal-body" style='margin:0rem;padding:1.5rem;'>
        <label style='padding-top:10px;font-weight:450;color:black;letter-spacing:0.6px;'>New Name Of Template</label>
  <input class='ip-by-def-dsg' id='rename_temp_name' name='rename_temp' type='text' style='padding-left:10px;height:40px;width:100%;' required/>
      </div>
      <div class="modal-footer">
       
        <button id='svg_temp_rename' type="btn_hover_clr" class='btn-theme-dsg' >Save changes</button>
      </div>
    </div>
  </div>
</div>











<div class="modal-2" data-modal="del_temp_modal" id='mdl-del-temp'>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delet Template</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i class="fal fa-times-circle"></i></span>
        </button>
      </div>
      <div class="modal-body">
        <label style='padding-top:10px;font-weight:450;color:black;letter-spacing:0.6px;'>Whish To Delet Template</label>
 <div id='del_temp_name' style='color:red;font-weight:700;'></div>
      </div>
      <div class="modal-footer">
        
        <button type="button" class='btn-theme-dsg' id='del_temp_fin' >Delete Template</button>
      </div>
    </div>
  </div>
</div>





<div class="modal fade" id="temp_review_con" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style='max-width:700px;'>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ovw_of_temp_name">Delet Template</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div id='temp_data_md'></div>
      </div>
      <div class="modal-footer">
       
       <a href='#' id='href_for_ovw_edit'> <button type="btn_hover_clr" class='bottom-btn'  ><span style='padding-right:10px;display:none' id='del_load'><i class="fas fa-circle-notch fa-spin" style=''></i></span>Edit Template</button></a>
      </div>
    </div>
  </div>
</div>




    
<div class="modal-2" data-modal="modal-send-api-data" id="mdl-send-api-data">
  <article class="content-wrapper">
    <button class="close"></button>
    <header class="modal-2-header">
      <h2>This Template Send For API Used.</h2>
    </header>
    <div class="content">
      <p>send template for API used and use this template content using heptera api. this feature is gives ability to developer send dynamic content with designed template without learn code.  <a class='hrf-doc-lnk' href="">Documentation</a></p>


    </div>

<div class='template-con-send'></div>

    <div class='content'>
   <p>Once You're send template for API Used admin not able to change or modified in template. </p>
   </div>

<div class="cont-of-res-api-tok-1" style="width:100%;">

    <button  class="btn-theme-dsg" id='send-for-api-connect' >Connect With API</button>

  </div>
   
 
  </article>
</div>









  <script src="./../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="./../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./../assets/js/argon-dashboard1.js"></script>
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>



temp_id_send_fr_api="";
  
main_url_of_page="http://heptera.me/dash/main/template/crt-template/crtedtemp/";



$(document).ready(function(){

req_for_temp_det();


});



function req_for_temp_det(){

nul_main_content();

append_load_large("#temp_to_res");


    
$.ajax({
    url : 'temp_res/gettempdata.php',
    type: 'GET'
  }).done(function(response){ //
   
      
    var get_res_temp=JSON.parse(response);
    
    
 length_of_array=get_res_temp.length;

if(length_of_array>0){

        for(i=0;i<length_of_array;i++){    
temp_thumb(get_res_temp[i]['name'],get_res_temp[i]['dateofcrt']);


  } 
    
    }else{


append_not_fd_str();


    }
   
rem_lds_all();
    
  });
    




}

function rem_lds_all(){

  $('.lds-ring').map(function() {
   

  $(this).remove();




});

}

function append_load_large(ele){

$(ele).html("<div class='lds-ring lds-color lds-large' id='lds-for-all-temp' style=''><div></div><div></div><div></div><div></div></div>");

}


function nul_main_content(){

$("#temp_to_res").empty();

}

function append_not_fd_str(){

$("#temp_to_res").append("<div class='not-fd-data'  > <img src='https://res.cloudinary.com/heptera/image/upload/v1599987331/template/team-discussing-on-website-development-2127159_leaodk.png' height='300'> <div class='txt-not-fd'> You Haven't Any Template Right Now. But dont Worry It's very Easzy to Create With heptera|<sub>edito</sub> </div> <a class='red_norm_url' red-url-dt='./crt-template'><button class='btn_hover_clr' style='float:none;'><i class='far fa-edit' aria-hidden='true' style=' padding-right: 10px; '></i>Creat Template</button></a> </div>");

}
function temp_thumb(temp_id,temp_crt_date){


var str_for_temp_res="<div  class='' style='padding-left:0px;padding-right:0px;margin:auto;'><div class='temp_con'><img class='temp_img_con' data-toggle='modal' data-target='#temp_review_con' src='http://heptera.me/dash/main/template/img-log/300*200.png'  width='215' height='250' id='img-of-temp' /><div class='row'><div class='temp_name_sty'>"+atob(temp_id.split("^")[1])+"</div><div class='edit_temp_name trigger' id='"+temp_id+"'    data-modal-trigger='rename_temp_name_modal'   style='padding:2px;'><i class='fal fa-pencil-alt' aria-hidden='true' style='width:20px;'></i></div><div class='dropdown' > <button  type='button' id='dropdownMenuButton' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'> <i class='far fa-ellipsis-v' aria-hidden='true'></i> </button> <div class='dropdown-menu dp-fr-opt-act' aria-labelledby='dropdownMenuButton' x-placement='bottom-start' style='position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 32px, 0px);'> <a class='dropdown-item open_edt_href' href='javascript:void(0);' id='"+temp_id+"'><i class='fal fa-edit' aria-hidden='true'></i>Edit</a> <a class='dropdown-item del_temp_name trigger' href='javascript:void(0);'  data-modal-trigger='del_temp_modal' id='"+temp_id+"'><i class='fal fa-trash-alt' aria-hidden='true'></i>Delete</a> <a class='dropdown-item click_to_copy'  href='javascript:void(0);' id="+temp_id+" ><i class='fal fa-copy' aria-hidden='true'></i>Copy</a> <a class='dropdown-item click_to_send_api trigger'    data-modal-trigger='modal-send-api-data'  href='javascript:void(0);' id="+temp_id+" ><i class='fal fa-link'></i>Connect To API</a> </div> </div></div><div style='padding-bottom:5px;font-size:13px;'>"+temp_crt_date+"</div></div></div></div>";

$("#temp_to_res").append(str_for_temp_res);

get_screen_shot(temp_id);

}


$(document).on("click",".open_edt_href",function(){

red_href="./edit/?editor_id="+$(this).attr("id");


red_url_load_fun(red_href);



});




$(document).on("click",".red_norm_url",function(){


red_url=$(this).attr("red-url-dt");


red_url_load_fun(red_url);

})


function red_url_load_fun(red_url){


$(".main-content").empty();



append_load_main_large(".main-content");



window.location.href =red_url;

}


function append_load_main_large(ele){

$(ele).html("<div class='lds-ring lds-color lds-large lds-main-large' id='lds-for-all-temp' style=''><div></div><div></div><div></div><div></div></div>");

}





function get_screen_shot(id_of_url){
	
		url=main_url_of_page+id_of_url+".html";
  url_main="http://ec2-3-21-105-231.us-east-2.compute.amazonaws.com/scr-api/?url="+url+"&width=700&height=800"; 



		$("#img-of-temp").attr("src",url_main);
		$("#img-of-temp").attr("id",id_of_url);

//document.getElementById(id_of_url+"img").src=url_main;

console.log(id_of_url);
}







$(document).on("click",".temp_img_con",function(){

var id_of_temp=$(this).attr("id");
$("#ovw_of_temp_name").html(atob(id_of_temp.split("^")[1]));
$("#temp_data_md").load('./crt-template/crtedtemp/'+id_of_temp+".html");
$("#href_for_ovw_edit").attr("href","./edit/?editor_id="+id_of_temp);

});








$(document).on("click",".click_to_copy",function(){
name_of_temp=$(this).attr("id");
decode_name_of_temp=$(this).attr("id");

        $.ajax({
  type: "POST",
  url: "./crt-template/ajaxfile/vertempname.php",
  data: {temp_name_get:name_of_temp,type_temp:decode_name_of_temp,temp_crt_flg:0}
}).done(function(response1) {

	if(response1==1){
location.reload();

	}else{
$("#res_of_proc").html("Please Try Again To Copy");
$("#res_of_proc").css("display","block");
	}
   
    
   
});




});














$(document).on("click",".edit_temp_name",function(){
temp_old_name=$(this).attr("id");

$("#rename_temp_name").val(atob(temp_old_name.split("^")[1]));

modalEvent(this);


});

$(document).on("click","#svg_temp_rename",function(){


$(this).prop( "disabled", true);


$(this).html('<div class="cp-spinner cp-round"></div>');

rename_temp_name=$("#rename_temp_name").val();
$("#rename_load").css("display","inline-block");


$.ajax({
  type: "POST",
  url: "./crt-template/ajaxfile/rename_temp.php",
  data: {temp_old_name:temp_old_name,temp_new_name:rename_temp_name}
}).done(function(response1) {

        if(response1==1){


$("#rnm-mdl-con").removeClass('open');

append_load_large("#temp_to_res");



req_for_temp_det();


        }else{
$("#res_of_proc").html("Please Try After Some Time");
$("#res_of_proc").css("display","block");
        }
   
    
   
});




});


$(document).on("click",".del_temp_name",function(){
del_temp=$(this).attr("id");

$("#del_temp_name").html(atob(del_temp.split("^")[1]));

modalEvent(this);

});

$(document).on("click","#del_temp_fin",function(){


$(this).prop('disabled', true);


$(this).html('<div class="cp-spinner cp-round"></div>');



$.ajax({
  type: "POST",
  url: "./crt-template/ajaxfile/del_temp.php",
  data: {temp_old_name:del_temp}
}).done(function(response1) {

        if(response1==1){





$("#mdl-del-temp").removeClass('open');

append_load_large("#temp_to_res");



req_for_temp_det();




        }else{
$("#res_of_proc").html(response1);
$("#res_of_proc").css("display","block");
        }
   
    
   
});




});



$(document).on("click",".click_to_send_api",function(){

temp_id_send_fr_api=$(this).attr('id');


$(".template-con-send").html(atob(temp_id_send_fr_api.split("^")[1]));


modalEvent(this);

});




function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
    const close = modal.querySelector('.close');

    close.addEventListener('click', () => modal.classList.remove('open'));
    

    modal.classList.toggle('open');
  
}



$(document).on("click","#send-for-api-connect",function(){




$(this).prop( "disabled", true);


$(this).html('<div class="cp-spinner cp-round"></div>');


$.ajax({
  type: "POST",
  url: "./ajaxfile/send_for_api.php",
  data: {temp_id:temp_id_send_fr_api}
}).done(function(response1) {


if(response1=='1'){



$("#mdl-send-api-data").removeClass('open');

append_load_large("#temp_to_res");



req_for_temp_det();



}
   
    
   
});




});



</script>
  
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>



