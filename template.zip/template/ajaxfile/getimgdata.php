<?php
require("../confige/imagesave.php");
$img_name=$_POST['img_name_get'];

$img_name1=explode("?",$img_name);

$org_img_name=str_replace("%5E","^",$img_name1);

$img_db_name=explode("^",$org_img_name[0]);
$dir_name= $img_db_name[0]."^".$img_db_name[1];


$sql = "SELECT * FROM `$dir_name` WHERE image='$org_img_name[0]'";
$result = $imagesave->query($sql);

if ($result->num_rows > 0) {
    $img_geted_data=$result->fetch_assoc();
    
    $json_img=json_encode($img_geted_data);
    echo $json_img;
    
} else {
    echo "0 results";
}

?>