<?php
session_start();

$id=$_SESSION['id'];
require("../confige/heptera_api_conn.php");



function getInbetweenStrings($start, $end, $str){
    $matches = array();
    $regex = "/$start([a-zA-Z0-9_]*)$end/";
    preg_match_all($regex, $str, $matches);
    return $matches[1];
}


$get_temp_id=$_POST['temp_id'];


$html = file_get_contents("../crt-template/crtedtemp/".$get_temp_id.".html");


$str_arr = getInbetweenStrings(':', ':', $html);


$str_arr=array_unique($str_arr);

foreach ($str_arr as $key => $value) {
    

$html=str_replace(":".$value.":","<?php echo \$_GET['".$value."'];?>",$html);


}

$camp_name=$id."^".strtotime("now");

$camp_save_dt_name_db=base64_encode($camp_name."#".$get_temp_id);

$camp_save_dt_name=$camp_save_dt_name_db.".php";

$myfile = fopen("../../api/api_temp/".$camp_save_dt_name, "w") or die("Unable to open file!");
$txt = $html;

$open_res_img_tag="<img src='http://ec2-3-12-107-213.us-east-2.compute.amazonaws.com/test/api/open_data_of_mail_act.php?lst_name=<?php echo \$_GET['lst_name'];?>&camp_name=".$camp_name."&con_id=<?php echo \$_GET['con_id'];?>'>";

fwrite($myfile, $open_res_img_tag);

fwrite($myfile, $txt);
fclose($myfile);



$insrt_data_int_api_temp_tbl="insert into `heptera-api-temp` (usr_id,temp_id) value ('$id','$camp_save_dt_name_db')";



if($heptera_api_conn->query($insrt_data_int_api_temp_tbl)==TRUE){

	echo 1;
}else{
	echo 0;
}


?>