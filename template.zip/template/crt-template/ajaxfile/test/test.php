<?php



require_once('php-image-magician/php_image_magician.php');

$magicianObj = new imageLib('../4^UmF2aS1jb3B5.jpg');

$magicianObj -> resizeImage(200, 250,'exact');
$magicianObj -> saveImage('racecar_small.png');
?>
